from regexp import *

def main():
    str = input()
    E = Empty()
    print( E.matches(str) )


if __name__ == "__main__":
    main()