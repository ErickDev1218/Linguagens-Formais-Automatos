def main():
    
    (states, edges, initial, final) = input()
    
    states2 = []
    edges2 = {}
    initial2 = 0
    final2 = []
    
    teste(states2, edges2, initial2, final2) 